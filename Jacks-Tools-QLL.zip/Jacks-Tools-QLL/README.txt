This is version 1.0.6! Created by Jaquez!

This is my first Python Project that actually worked! Yay!

youtube: @When Never
discord: @h7b7k (dms should be open, always taking questions!)

** GUIDE **
Input a name, and URL, select a group (bottom left) or create a group. (input a group name and press '+')
Add Link, and click on the link, press open link, and you are directed to that link.
dont worry, you go straight to where you wanted too, no extra ip grabbers or what not.
Click on a group, and click open link, this will open all links in that group.

Release Notes:

1.0.0
- First Testing of the software, very crude but it works
1.0.5
-Went straight to .5 because its halfway to 1.1.0
-Fixed all the bugs and the software runs smoothly.
1.0.6
-Fixed a software breaking bug